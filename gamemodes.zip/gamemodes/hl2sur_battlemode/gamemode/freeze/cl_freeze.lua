// Freeze Teams

CreateConVar( "freeze_teams", "0", { FCVAR_REPLICATED + FCVAR_ARCHIVE } )