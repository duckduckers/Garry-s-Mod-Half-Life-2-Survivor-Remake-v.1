// test
// herp

// Enable Friendly Fire Message
function vb_msg_ff_enable_1()
	chat.AddText( Color( 255, 255, 255 ), "[", Color( 255, 0, 0 ), "TDM", Color( 255, 255, 255 ), "] ", Color( 255, 255, 255 ), "Activating Friendly Fire!" )
end
usermessage.Hook("vb_msg_ff_enable_1", vb_msg_ff_enable_1)

// No Class Message
function vb_no_class()
	chat.AddText( Color( 255, 255, 255 ), "[", Color( 255, 0, 0 ), "TDM", Color( 255, 255, 255 ), "] ", Color( 255, 255, 255 ), "You need to choose a class! Open the menu up, and choose a class!" )
end
usermessage.Hook("vb_no_class", vb_no_class)

// Disable Friendly Fire Message
function vb_msg_ff_enable_2()
	chat.AddText( Color( 255, 255, 255 ), "[", Color( 255, 0, 0 ), "TDM", Color( 255, 255, 255 ), "] ", Color( 255, 255, 255 ), "Disabling Friendly Fire!" )
end
usermessage.Hook("vb_msg_ff_enable_2", vb_msg_ff_enable_2)

// Create a bot!
function vb_msg_create_bot()
	chat.AddText( Color( 255, 255, 255 ), "[", Color( 255, 0, 0 ), "TDM", Color( 255, 255, 255 ), "] ", Color( 255, 255, 255 ), "Creating a bot!" )
end
usermessage.Hook("vb_msg_create_bot", vb_msg_create_bot)

// Teams Lock
function vb_msg_teams_lock()
	chat.AddText( Color( 255, 255, 255 ), "[", Color( 255, 0, 0 ), "TDM", Color( 255, 255, 255 ), "] ", Color( 255, 255, 255 ), "Locking all teams!" )
end
usermessage.Hook("vb_msg_teams_lock", vb_msg_teams_lock)

// Teams Unlock
function vb_msg_teams_unlock()
	chat.AddText( Color( 255, 255, 255 ), "[", Color( 255, 0, 0 ), "TDM", Color( 255, 255, 255 ), "] ", Color( 255, 255, 255 ), "Unlocking all teams!" )
end
usermessage.Hook("vb_msg_teams_unlock", vb_msg_teams_unlock)

// Goal 1
function vb_msg_win_goal_1()
	chat.AddText( Color( 255, 255, 255 ), "[", Color( 255, 0, 0 ), "TDM", Color( 255, 255, 255 ), "] ", Color( 255, 255, 255 ), "Goal limit changed to 10!" )
end
usermessage.Hook("vb_msg_win_goal_1", vb_msg_win_goal_1)

// Goal 2
function vb_msg_win_goal_2()
	chat.AddText( Color( 255, 255, 255 ), "[", Color( 255, 0, 0 ), "TDM", Color( 255, 255, 255 ), "] ", Color( 255, 255, 255 ), "Goal limit changed to 20!" )
end
usermessage.Hook("vb_msg_win_goal_2", vb_msg_win_goal_2)

// Goal 3
function vb_msg_win_goal_3()
	chat.AddText( Color( 255, 255, 255 ), "[", Color( 255, 0, 0 ), "TDM", Color( 255, 255, 255 ), "] ", Color( 255, 255, 255 ), "Goal limit changed to 30!" )
end
usermessage.Hook("vb_msg_win_goal_3", vb_msg_win_goal_3)

// Goal 4
function vb_msg_win_goal_4()
	chat.AddText( Color( 255, 255, 255 ), "[", Color( 255, 0, 0 ), "TDM", Color( 255, 255, 255 ), "] ", Color( 255, 255, 255 ), "Goal limit changed to 40!" )
end
usermessage.Hook("vb_msg_win_goal_4", vb_msg_win_goal_4)

// Goal 5
function vb_msg_win_goal_5()
	chat.AddText( Color( 255, 255, 255 ), "[", Color( 255, 0, 0 ), "TDM", Color( 255, 255, 255 ), "] ", Color( 255, 255, 255 ), "Goal limit changed to 50!" )
end
usermessage.Hook("vb_msg_win_goal_5", vb_msg_win_goal_5)

// Goal 6
function vb_msg_win_goal_6()
	chat.AddText( Color( 255, 255, 255 ), "[", Color( 255, 0, 0 ), "TDM", Color( 255, 255, 255 ), "] ", Color( 255, 255, 255 ), "Goal limit changed to 60!" )
end
usermessage.Hook("vb_msg_win_goal_6", vb_msg_win_goal_6)

// Goal 7
function vb_msg_win_goal_7()
	chat.AddText( Color( 255, 255, 255 ), "[", Color( 255, 0, 0 ), "TDM", Color( 255, 255, 255 ), "] ", Color( 255, 255, 255 ), "Goal limit changed to 70!" )
end
usermessage.Hook("vb_msg_win_goal_7", vb_msg_win_goal_7)

// Goal 8
function vb_msg_win_goal_8()
	chat.AddText( Color( 255, 255, 255 ), "[", Color( 255, 0, 0 ), "TDM", Color( 255, 255, 255 ), "] ", Color( 255, 255, 255 ), "Goal limit changed to 80!" )
end
usermessage.Hook("vb_msg_win_goal_8", vb_msg_win_goal_8)

// Goal 9
function vb_msg_win_goal_9()
	chat.AddText( Color( 255, 255, 255 ), "[", Color( 255, 0, 0 ), "TDM", Color( 255, 255, 255 ), "] ", Color( 255, 255, 255 ), "Goal limit changed to 90!" )
end
usermessage.Hook("vb_msg_win_goal_9", vb_msg_win_goal_9)

// Goal 10
function vb_msg_win_goal_10()
	chat.AddText( Color( 255, 255, 255 ), "[", Color( 255, 0, 0 ), "TDM", Color( 255, 255, 255 ), "] ", Color( 255, 255, 255 ), "Goal limit changed to 100!" )
end
usermessage.Hook("vb_msg_win_goal_10", vb_msg_win_goal_10)

// Goal 0
function vb_msg_win_goal_0()
	chat.AddText( Color( 255, 255, 255 ), "[", Color( 255, 0, 0 ), "TDM", Color( 255, 255, 255 ), "] ", Color( 255, 255, 255 ), "Goal limit has been removed!" )
end
usermessage.Hook("vb_msg_win_goal_0", vb_msg_win_goal_0)

// Goal Custom
function vb_msg_win_goal_custom( data )
local goal_limit = data:ReadString()
	chat.AddText( Color( 255, 255, 255 ), "[", Color( 255, 0, 0 ), "TDM", Color( 255, 255, 255 ), "] ", Color( 255, 255, 255 ), "Goal limit changed to "..goal_limit )
end
usermessage.Hook("vb_msg_win_goal_custom", vb_msg_win_goal_custom)

// Reset Score
function vb_msg_reset_score()
	chat.AddText( Color( 255, 255, 255 ), "[", Color( 255, 0, 0 ), "TDM", Color( 255, 255, 255 ), "] ", Color( 255, 255, 255 ), "Resetting all scores!" )
end
usermessage.Hook("vb_msg_reset_score", vb_msg_reset_score)

// Armor On
function vb_msg_armor_on()
	chat.AddText( Color( 255, 255, 255 ), "[", Color( 255, 0, 0 ), "TDM", Color( 255, 255, 255 ), "] ", Color( 255, 255, 255 ), "Armor spawning is now on!" )
end
usermessage.Hook("vb_msg_armor_on", vb_msg_armor_on)

// Armor Off
function vb_msg_armor_off()
	chat.AddText( Color( 255, 255, 255 ), "[", Color( 255, 0, 0 ), "TDM", Color( 255, 255, 255 ), "] ", Color( 255, 255, 255 ), "Armor spawning is now off!" )
end
usermessage.Hook("vb_msg_armor_off", vb_msg_armor_off)

// Kill myself
function vb_msg_kill_self()
	chat.AddText( Color( 255, 255, 255 ), "[", Color( 255, 0, 0 ), "TDM", Color( 255, 255, 255 ), "] ", Color( 255, 255, 255 ), "Sorry, but you can't kill yourself!" )
end
usermessage.Hook("vb_msg_kill_self", vb_msg_kill_self)

// Create a Team Admin
function vb_msg_team_admin()
	chat.AddText( Color( 255, 255, 255 ), "[", Color( 255, 0, 0 ), "TDM", Color( 255, 255, 255 ), "] ", Color( 255, 255, 255), "Switching to ", Color( 255, 102, 255 ), "ADMIN!" )
end
usermessage.Hook("vb_msg_team_admin", vb_msg_team_admin)

// Your not admin!
function vb_msg_not_admin()
	chat.AddText( Color( 255, 255, 255 ), "[", Color( 255, 0, 0 ), "TDM", Color( 255, 255, 255 ), "] ", Color( 255, 255, 255 ), "Sorry, but your not admin!" )
end
usermessage.Hook("vb_msg_not_admin", vb_msg_not_admin)

// Switching to US team
function vb_msg_team_US()
	chat.AddText( Color( 255, 255, 255 ), "[", Color( 255, 0, 0 ), "TDM", Color( 255, 255, 255 ), "] ", Color( 255, 255, 255 ), "Switching to ", Color( 0, 0, 255 ), "Blue", Color( 255, 255, 255), " team." )
end
usermessage.Hook("vb_msg_team_US", vb_msg_team_US)

// Switching to German team
function vb_msg_team_Germany()
	chat.AddText( Color( 255, 255, 255 ), "[", Color( 255, 0, 0 ), "TDM", Color( 255, 255, 255 ), "] ", Color( 255, 255, 255 ), "Switching to ", Color( 255, 0, 0 ), "Red", Color( 255, 255, 255), " team." )
end
usermessage.Hook("vb_msg_team_Germany", vb_msg_team_Germany)

// Switching to Class 1
function vb_msg_class_1()
	chat.AddText( Color( 255, 255, 255 ), "[", Color( 255, 0, 0 ), "TDM", Color( 255, 255, 255 ), "] ", Color( 255, 255, 255 ), "Switching to class one. When you respawn, you'll start with your class." )
end
usermessage.Hook("vb_msg_class_1", vb_msg_class_1)

// Switching to Class 2
function vb_msg_class_2()
	chat.AddText( Color( 255, 255, 255 ), "[", Color( 255, 0, 0 ), "TDM", Color( 255, 255, 255 ), "] ", Color( 255, 255, 255 ), "Switching to class two. When you respawn, you'll start with your class." )
end
usermessage.Hook("vb_msg_class_2", vb_msg_class_2)

// Switching to Class 3
function vb_msg_class_3()
	chat.AddText( Color( 255, 255, 255 ), "[", Color( 255, 0, 0 ), "TDM", Color( 255, 255, 255 ), "] ", Color( 255, 255, 255 ), "Switching to class three. When you respawn, you'll start with your class." )
end
usermessage.Hook("vb_msg_class_3", vb_msg_class_3)

// SSorry but teams are locked
function vb_msg_team_are_locked()
	chat.AddText( Color( 255, 255, 255 ), "[", Color( 255, 0, 0 ), "TDM", Color( 255, 255, 255 ), "] ", Color( 255, 255, 255 ), "Sorry, but the teams are locked!" )
end
usermessage.Hook("vb_msg_team_are_locked", vb_msg_team_are_locked)