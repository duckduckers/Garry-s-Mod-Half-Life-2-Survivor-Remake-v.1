GM.Name 	= "HL2:S BM"
GM.Author 	= "SnowFoxMedia"
GM.Email 	= ""
GM.Website 	= ""



// Null teams
team.SetUp( 1, "Admin", Color( 209, 66, 245 ) ) --Team Admin
team.SetUp( 9, "Guest", Color( 122, 122, 122, 255 ) ) --Team Guest
team.SetUp( 8, "BOT", Color( 35, 69, 102 , 255 ) ) --Team Bot

// Setting up teams
team.SetUp( 2, "Combine", Color( 51, 102, 255, 255 ) ) --Team Blue
team.SetUp( 3, "Rebels", Color( 255, 215, 0 , 255 ) ) --Team Red

//Null Team
team.SetUp( 1337, "Null", Color( 255, 215, 0 , 255 ) ) --Team Orange
