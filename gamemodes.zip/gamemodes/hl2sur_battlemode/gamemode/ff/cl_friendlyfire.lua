// Friendly Fire testng script
