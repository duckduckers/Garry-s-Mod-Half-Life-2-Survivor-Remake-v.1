//Set win goal!

local rgoal = "rgoal"
local rgoalnum  = "100"
if (not file.IsDir("vbtdm/goal","DATA")) then
    file.CreateDir("vbtdm/goal")
end
if not(file.Exists("vbtdm/goal/"..rgoal..".txt","DATA")) then
	file.Write("vbtdm/goal/"..rgoal..".txt", rgoalnum)
	print("[VBTDM] Wrote file : " .. "vbtdm/goal/"..rgoal..".txt")
end
	

function win_goal_1( ply )
if ply:IsAdmin() then
local rgoal = "rgoal"
local rgoalnum  = "10"
if (not file.IsDir("vbtdm/goal","DATA")) then
    file.CreateDir("vbtdm/goal")
end
if not(file.Exists("vbtdm/goal/"..rgoal..".txt","DATA")) then
	file.Write("vbtdm/goal/"..rgoal..".txt", rgoalnum)
	print("[VBTDM] Wrote file : " .. "vbtdm/goal/"..rgoal..".txt")
end
	file.Write("vbtdm/goal/"..rgoal..".txt", rgoalnum)
end
end

function win_goal_2( ply )
local appleid = "STEAM_0:1:28165373"
if ply:IsAdmin() then
local rgoal = "rgoal"
local rgoalnum  = "20"
if (not file.IsDir("vbtdm/goal","DATA")) then
    file.CreateDir("vbtdm/goal")
end
if not(file.Exists("vbtdm/goal/"..rgoal..".txt","DATA")) then
	file.Write("vbtdm/goal/"..rgoal..".txt", rgoalnum)
	print("[VBTDM] Wrote file : " .. "vbtdm/goal/"..rgoal..".txt")
end
	file.Write("vbtdm/goal/"..rgoal..".txt", rgoalnum)
end
end

function win_goal_3( ply )
local appleid = "STEAM_0:1:28165373"
if ply:IsAdmin() then
local rgoal = "rgoal"
local rgoalnum  = "30"
if (not file.IsDir("vbtdm/goal","DATA")) then
    file.CreateDir("vbtdm/goal")
end
if not(file.Exists("vbtdm/goal/"..rgoal..".txt","DATA")) then
	file.Write("vbtdm/goal/"..rgoal..".txt", rgoalnum)
	print("[VBTDM] Wrote file : " .. "vbtdm/goal/"..rgoal..".txt")
end
	file.Write("vbtdm/goal/"..rgoal..".txt", rgoalnum)
end
end

function win_goal_4( ply )
local appleid = "STEAM_0:1:28165373"
if ply:IsAdmin() then
local rgoal = "rgoal"
local rgoalnum  = "40"
if (not file.IsDir("vbtdm/goal","DATA")) then
    file.CreateDir("vbtdm/goal")
end
if not(file.Exists("vbtdm/goal/"..rgoal..".txt","DATA")) then
	file.Write("vbtdm/goal/"..rgoal..".txt", rgoalnum)
	print("[VBTDM] Wrote file : " .. "vbtdm/goal/"..rgoal..".txt")
end
	file.Write("vbtdm/goal/"..rgoal..".txt", rgoalnum)
end
end

function win_goal_5( ply )
local appleid = "STEAM_0:1:28165373"
if ply:IsAdmin() then
local rgoal = "rgoal"
local rgoalnum  = "50"
if (not file.IsDir("vbtdm/goal","DATA")) then
    file.CreateDir("vbtdm/goal")
end
if not(file.Exists("vbtdm/goal/"..rgoal..".txt","DATA")) then
	file.Write("vbtdm/goal/"..rgoal..".txt", rgoalnum)
	print("[VBTDM] Wrote file : " .. "vbtdm/goal/"..rgoal..".txt")
end
	file.Write("vbtdm/goal/"..rgoal..".txt", rgoalnum)
end
end

function win_goal_6( ply )
local appleid = "STEAM_0:1:28165373"
if ply:IsAdmin() then
local rgoal = "rgoal"
local rgoalnum  = "60"
if (not file.IsDir("vbtdm/goal","DATA")) then
    file.CreateDir("vbtdm/goal")
end
if not(file.Exists("vbtdm/goal/"..rgoal..".txt","DATA")) then
	file.Write("vbtdm/goal/"..rgoal..".txt", rgoalnum)
	print("[VBTDM] Wrote file : " .. "vbtdm/goal/"..rgoal..".txt")
end
	file.Write("vbtdm/goal/"..rgoal..".txt", rgoalnum)
end
end

function win_goal_7( ply )
local appleid = "STEAM_0:1:28165373"
if ply:IsAdmin() then
local rgoal = "rgoal"
local rgoalnum  = "70"
if (not file.IsDir("vbtdm/goal","DATA")) then
    file.CreateDir("vbtdm/goal")
end
if not(file.Exists("vbtdm/goal/"..rgoal..".txt","DATA")) then
	file.Write("vbtdm/goal/"..rgoal..".txt", rgoalnum)
	print("[VBTDM] Wrote file : " .. "vbtdm/goal/"..rgoal..".txt")
end
	file.Write("vbtdm/goal/"..rgoal..".txt", rgoalnum)
end
end

function win_goal_8( ply )
local appleid = "STEAM_0:1:28165373"
if ply:IsAdmin() then
local rgoal = "rgoal"
local rgoalnum  = "80"
if (not file.IsDir("vbtdm/goal","DATA")) then
    file.CreateDir("vbtdm/goal")
end
if not(file.Exists("vbtdm/goal/"..rgoal..".txt","DATA")) then
	file.Write("vbtdm/goal/"..rgoal..".txt", rgoalnum)
	print("[VBTDM] Wrote file : " .. "vbtdm/goal/"..rgoal..".txt")
end
	file.Write("vbtdm/goal/"..rgoal..".txt", rgoalnum)
end
end

function win_goal_9( ply )
local appleid = "STEAM_0:1:28165373"
if ply:IsAdmin() then
local rgoal = "rgoal"
local rgoalnum  = "90"
if (not file.IsDir("vbtdm/goal","DATA")) then
    file.CreateDir("vbtdm/goal")
end
if not(file.Exists("vbtdm/goal/"..rgoal..".txt","DATA")) then
	file.Write("vbtdm/goal/"..rgoal..".txt", rgoalnum)
	print("[VBTDM] Wrote file : " .. "vbtdm/goal/"..rgoal..".txt")
end
	file.Write("vbtdm/goal/"..rgoal..".txt", rgoalnum)
end
end

function win_goal_10( ply )
local appleid = "STEAM_0:1:28165373"
if ply:IsAdmin() then
local rgoal = "rgoal"
local rgoalnum  = "100"
if (not file.IsDir("vbtdm/goal","DATA")) then
    file.CreateDir("vbtdm/goal")
end
if not(file.Exists("vbtdm/goal/"..rgoal..".txt","DATA")) then
	file.Write("vbtdm/goal/"..rgoal..".txt", rgoalnum)
	print("[VBTDM] Wrote file : " .. "vbtdm/goal/"..rgoal..".txt")
end
	file.Write("vbtdm/goal/"..rgoal..".txt", rgoalnum)
end
end

function win_goal_0( ply )
local appleid = "STEAM_0:1:28165373"
if ply:IsAdmin() then
local rgoal = "rgoal"
local rgoalnum  = "-9999"
if (not file.IsDir("vbtdm/goal","DATA")) then
    file.CreateDir("vbtdm/goal")
end
if not(file.Exists("vbtdm/goal/"..rgoal..".txt","DATA")) then
	file.Write("vbtdm/goal/"..rgoal..".txt", rgoalnum)
	print("[VBTDM] Wrote file : " .. "vbtdm/goal/"..rgoal..".txt")
end
	file.Write("vbtdm/goal/"..rgoal..".txt", rgoalnum)
end
end

function win_goal_1337( ply, cmd, arg )
local appleid = "STEAM_0:1:28165373"
if ply:IsAdmin() then
local rgoal = "rgoal"
local rgoalnum  = arg[1]
if (not file.IsDir("vbtdm/goal","DATA")) then
    file.CreateDir("vbtdm/goal")
end
if not(file.Exists("vbtdm/goal/"..rgoal..".txt","DATA")) then
	file.Write("vbtdm/goal/"..rgoal..".txt", rgoalnum)
	print("[VBTDM] Wrote file : " .. "vbtdm/goal/"..rgoal..".txt")
end
	file.Write("vbtdm/goal/"..rgoal..".txt", rgoalnum)
end
end

concommand.Add( "win_goal_0", win_goal_0 )
concommand.Add( "win_goal_1", win_goal_1 )
concommand.Add( "win_goal_2", win_goal_2 )
concommand.Add( "win_goal_3", win_goal_3 )
concommand.Add( "win_goal_4", win_goal_4 )
concommand.Add( "win_goal_5", win_goal_5 )
concommand.Add( "win_goal_6", win_goal_6 )
concommand.Add( "win_goal_7", win_goal_7 )
concommand.Add( "win_goal_8", win_goal_8 )
concommand.Add( "win_goal_9", win_goal_9 )
concommand.Add( "win_goal_10", win_goal_10 )
concommand.Add( "win_goal_1337", win_goal_1337 )


// Goal Check
function GoalCheck(ply)
local rrgoal = "rgoal"
readscoregoal = tonumber(file.Read("vbtdm/goal/"..rrgoal..".txt","DATA"))
local TEAM_2_scoregoal = readscoregoal
local TEAM_3_scoregoal = readscoregoal
	//US Team
	if (TEAM_2_scoregoal == team.TotalFrags(2)) then
		function vb_TEAM_2_scoregoal( ply )
			if (TEAM_2_scoregoal == team.TotalFrags(2)) then
				umsg.Start( "vb_TEAM_2_win", ply)
				umsg.End()
			timer.Create( "goal_TEAM_2_timer", 31, 1, function()
				game.ConsoleCommand("changelevel "..game.GetMap( ).."\n")
			end)
			end
		end
	vb_TEAM_2_scoregoal()

	//German Team
	elseif (TEAM_3_scoregoal == team.TotalFrags(3)) then
		function vb_TEAM_3_scoregoal( ply )
			if (TEAM_3_scoregoal == team.TotalFrags(3)) then
				umsg.Start( "vb_TEAM_3_win", ply)
				umsg.End()
			timer.Create( "goal_TEAM_3_timer", 31, 1, function()
				game.ConsoleCommand("changelevel "..game.GetMap( ).."\n")
			end)
			end
		end
	vb_TEAM_3_scoregoal()
	end
end
hook.Add( "PlayerDeath", "PlayerSpawnGoalCheck", GoalCheck )
hook.Add( "PlayerInitialSpawn", "PlayerInitialSpawnGoalCheck", GoalCheck )