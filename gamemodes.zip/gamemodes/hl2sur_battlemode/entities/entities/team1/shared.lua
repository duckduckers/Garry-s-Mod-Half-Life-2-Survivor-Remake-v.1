ENT.Type = "anim"
 
ENT.PrintName		= "SpawnPoint"
ENT.Author			= "SHOOP DA WHOOP"
ENT.Contact			= "warspigot.com"
ENT.Purpose			= "To Spawn People"
ENT.Instructions	= "You shouldn't be using it yourself" 